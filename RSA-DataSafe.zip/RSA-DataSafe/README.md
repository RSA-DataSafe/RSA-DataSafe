# Interface_Graphic
#installer dabord gtk 
ensuite  la commande "make" 
